#!/bin/bash
systemctl restart httpd